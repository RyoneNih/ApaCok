const donasi = (prefix) => {
	return `*RYOBOT*
          
┏━━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━━┓
┃
┏❉ *${prefix}info*
┃❉ *${prefix}help* 
┗❉ *${prefix}creator* 
┃
┣━━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃╔➥ *SAWERIA:* Gk ada :v
┃╠➥ *PULSA:* 0821-5758-1762
┃╚➥ *KUOTA:* Telkom
┣━━━━°❀ *❬ SOSMED ❭* ❀°━━━━⊱
┃ *Ada masalah? Hub :*
┃ _wa.me/6282157581762_
┃ *Instagram :* @ff.ryone
┃ *YouTube :*
┃ _Ryone Ch_
┃ *Twitter :* Gk punya:v
┃ *SC BY Anoynimous Dunk:v*
┣━━━━━━━━━━━━━━━━━━━━━┓
┃ *❬ POWERD BY RYONE ❭*
┗━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.donasi = donasi
