
const help = (prefix) => { 
	return ` *📌MENU RYOBOT 📌*
	




┏━━━━°❀ ❄1�7 𝘼𝘽𝙊𝙐𝙏 ❄1�7 ❄1�7°━━━━━━┄1�7
┃⊱❄1�7 *RYOBOT*
┃⊱❄1�7 *V 5.0*
┃⊱❄1�7 *:v*
┃⊱❄1�7 *Ryone Rend*
┣━━━━━━━━━━━━━━━━━━━┄1�7
┄1�7
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┄1�7
┣━━━━°❀ *❄1�7 MAKER ❄1�7* ❄1�7°━━━━⊄1�7
┃╔❄1�7 *${prefix}sticker*
┃╠❄1�7 *${prefix}sticker nobg*
┃╠❄1�7 *${prefix}tsticker*
┃╠❄1�7 *${prefix}nulis*
┃╚❄1�7 *${prefix}logowolf*
┣━━━━°❀ *❄1�7 MEDIA ❄1�7* ❄1�7°━━━━━⊱
┃╔❄1�7 *${prefix}tts*
┃╠❄1�7 *${prefix}tiktok*
┃╠❄1�7 *${prefix}meme*
┃╠❄1�7 *${prefix}memeindo*
┃╠❄1�7 *${prefix}nsfwloli* 
┃╠❄1�7 *${prefix}ocr*
┃╠❄1�7 *${prefix}neko*
┃╠❄1�7 *${prefix}randomanime*
┃╠❄1�7 *${prefix}loli*
┃╚❄1�7 *${prefix}waifu*
┣━━━°❄1�7 *❄1�7 DOWNLOAD ❄1�7* ❄1�7°━━⊄1�7
┃╔❄1�7 *${prefix}ytmp3*
┃╚❄1�7 *${prefix}ytmp4*
┣━━━━°❀ *❄1�7 GROUP ❄1�7* ❄1�7°━━━━⊄1�7
┃╔❄1�7 *${prefix}add* [62xxx]
┃╠❄1�7 *${prefix}kick* [tag]
┃╠❄1�7 *${prefix}setpp*
┃╠❄1�7 *${prefix}tagme*
┃╠❄1�7 *${prefix}demote* [tag]
┃╠❄1�7 *${prefix}promote* [tag]
┃╠❄1�7 *${prefix}grup* [buka/tutup]
┃╠❄1�7 *${prefix}welcome* [1/0]
┃╠❄1�7 *${prefix}nsfw* [1/0]
┃╚❄1�7 *${prefix}simih* [1/0]
┣━━━━°❀ *❄1�7 OWNER ❄1�7* ❄1�7°━━━━⊄1�7
┃╔❄1�7 *${prefix}bc* 
┃╠❄1�7 *${prefix}clearall*
┃╠❄1�7 *${prefix}setprefix*
┃╠❄1�7 *${prefix}leave*
┃╚❄1�7 *${prefix}clone* [tag]
┣━━━━━°❄1�7 *❄1�7 SPAM ❄1�7* ❄1�7°━━━━━⊱
┃╔❄1�7 *${prefix}spamsms*
┃╠❄1�7 *${prefix}spamcall*
┃╚❄1�7 *${prefix}spamgmail*
┣━━━━°❀ *❄1�7 OTHER ❄1�7* ❄1�7°━━━━⊄1�7
┃╔❄1�7 *${prefix}ytsearch*
┃╠❄1�7 *${prefix}listadmin*
┃╠❄1�7 *${prefix}blocklist*
┃╠❄1�7 *${prefix}wait*
┃╠❄1�7 *${prefix}nama*
┃╠❄1�7 *${prefix}map*
┃╠❄1�7 *${prefix}qrcode*
┃╠❄1�7 *${prefix}tiktokstalk*
┃╠❄1�7 *${prefix}shortlink*
┃╠❄1�7 *${prefix}url2img*
┃╠❄1�7 *${prefix}alay*
┃╠❄1�7 *${prefix}quotes*
┃╠❄1�7 *${prefix}bucin*
┃╠❄1�7 *${prefix}wiki*
┃╚❄1�7 *${prefix}wikien*
┣━━━━°❀ *❄1�7 SOUND ❄1�7* ❄1�7°━━━━⊄1�7
┃╠❄1�7 *${prefix}tapi*
┣━━━━°❀ *❄1�7 SOSMED ❄1�7* ❄1�7°━━━━⊄1�7
┄1�7 *Ada masalah? Hub :*
┄1�7 _wa.me/6282157581762_
┄1�7 *Instagram :* @ff.ryone
┄1�7 *YouTube :*
┄1�7 Ryone Ch
┄1�7 *Twitter :* Gk ada :v
┄1�7 *SC BY Anoynimous Dong :v*
┣━━━━━━━━━━━━━━━━━━━━━┄1�7
┄1�7  *❄1�7 POWERD BY Ryone ❄1�7*  
┗━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.help = help

 
